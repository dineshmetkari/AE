import React, { Component } from 'react';
import QuestionProperties from './questionProperties';
class App extends Component {

  render() {
    return (
      <div>
        <QuestionProperties />
      </div>

    );
  }

}


export default App;
