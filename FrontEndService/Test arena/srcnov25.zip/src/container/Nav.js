import React from 'react';
import ReactDom from 'react-dom';
import AppBar from 'material-ui/AppBar';
import {Link} from 'react-router';
export default class Nav extends React.Component{
	render(){
		return(
			<div>
			<AppBar
				 title="Test Arena"
			 />
		      </div>
			);
	}
}
